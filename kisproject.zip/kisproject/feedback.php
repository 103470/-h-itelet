<?php 

    require 'connect.php';?>


<?php
    
    if(isset($_POST['submit'])){
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $role = $_POST['role'];
        $q1 = $_POST['q1'];
        $q2 = $_POST['q2'];
        $text = $_POST['text'];

        $con->query("INSERT INTO feedback (firstname, lastname, email, age, gender, role, q1, q2, text) VALUES ('$firstname', '$lastname', '$email', '$age', '$gender', '$role', '$q1', '$q2', '$text')");
        $_SESSION['message'] = "Köszönjök, válasza sokat jelent számunkra!";
        header('location: feedback.php');

        $firstname = '';
        $lastname = '';
        $email= '';
        $age= '';
        $role= '';
        $q1= '';
        $q2= '';
        $text= '';

        
    }

        
    
    

    
       
    
    


?>

<!DOCTYPE html>
<html>
    <body>
        <head>
            <title>FeedBack Form</title>
            <meta charset="utf-8">
            <link rel="stylesheet" type="text/css" href="style.css">
    
    
        </head>
        <header class="title">
            <h1>FeedBack Form</h1>
        </header>
        <?php if(isset($_SESSION['message'])): ?>
                <div class="alert">
                    <?php
                        echo $_SESSION['message'];
                        unset($_SESSION['message']);
                    ?>
                </div>
            <?php endif;?>
        <section>
            <div class="container">
                <div class="description">
                    <p>Kérjük válaszolja meg az alábbi pár kérdést a webáruházzal kapcsolatban!</p>
                </div>
                <form action="feedback.php" method="post">
                    <label>Vezetéknév (nem kötelező):</label><br>
                    <input type="text" name="firstname" placeholder="Írd be a vezetékneved" class="text"><br><br>
                    
                    <label>Keresztnév (Nem kötelező):</label><br>
                    <input type="text" name="lastname" placeholder="Írd be a keresztneved" class="text"><br><br>
                    
                    <label>E-mail (nem kötelező):</label><br>
                    <input type="email" name="email" placeholder="Írd be az e-mail címed" class="text"><br><br>
                    
                    <label>Életkor:</label><br>
                    <input type="number" name="age" placeholder="Add meg az életkorod" class="text" required><br><br>

                    <label>Neme:</label><br>
                    <select name="gender" class="select" required><br>
                        <option value=""></option><br>
                        <option value="Férfi">Férfi</option><br>
                        <option value="Nő">Nő</option><br>
                        <option value="Nem adom meg">Nem adom meg</option><br>
                    </select><br><br>
                   
                    <label>Foglalkoztatottság:</label><br>
                    <select name="role" class="select" required><br>
                        <option value=""></option>
                        <option value="Tanulo">Tanuló</option><br>
                        <option value="Alkalmazott">Alkalmazott</option><br>
                        <option value="Nem adom meg">Nem adom meg</option><br>
                    </select><br><br>
                  
                    <label>Ajánlaná-e a webáruházunkat barátainak/ismerőseinek?</label><br>
                    <input type="radio" class="radio" name="q1" value="Igen, ajánlanám" required><label>Igen, ajánlanám</label><br>
                    <input type="radio" class="radio" name="q1" value="Semleges"required><label>Semleges</label><br>
                    <input type="radio" class="radio" name="q1" value="Nem ajánlanám" required><label>Nem ajánlanám</label><br><br>
                          
                    <label>Mennyire elégedett az oldal megbízhatóságával?</label><br>
                    <input type="radio" class="radio" name="q2" value="Elégedett vagyok" required><label>Elégedett vagyok</label><br>
                    <input type="radio" class="radio" name="q2" value="Semleges" required><label>Semleges</label><br>
                    <input type="radio" class="radio" name="q2" value="Nem vagyok elégedett" required><label>Nem vagyok elégedett</label><br><br>
                           
                    <label>Írja le saját gondolatait:</label><br>
                    <textarea class="textbox" name="text"></textarea><br><br>
                        
                    <button name="submit" value="Befejezés">Befejezés</button>
                </form>

            </div>


        </section>
        
    </body>


</html>




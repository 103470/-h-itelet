<?php
    session_start();

    $con = mysqli_connect('localhost','root','','kisprojekt') or die("Hiba történt");

    $errors = array();

?>
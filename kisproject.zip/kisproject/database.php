<?php
    require 'connect.php'; ?>

<?php
    
    $result = $con->query("SELECT * FROM feedback");

    if(!isset($_SESSION['username'])){
        header("location: login.php");
    }


?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Adatbázis</title>
        <link rel="stylesheet" href="table.css" type="text/css">
    </head>
    <ul>
        <a href="logout.php">Kijelentkezés</a>
    </ul>
    <body>
        <table class="table">
            <thead>
                <tr>
                    <th>Vezetéknév</th>
                    <th>Keresztnév</th>
                    <th>E-mail</th>
                    <th>Életkor</th>
                    <th>Neme</th>
                    <th>Foglalkoztatottság</th>
                    <th>Ajánlás</th>
                    <th>Értékelés</th>
                    <th>Vélemény</th>
                </tr>
            </thead>
            <?php while($row = $result->fetch_assoc()): ?>
            <tbody>
                <tr>
                    <td><?php echo $row['firstname']; ?></td>
                    <td><?php echo $row['lastname']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['age']; ?></td>
                    <td><?php echo $row['gender']; ?></td>
                    <td><?php echo $row['role']; ?></td>
                    <td><?php echo $row['q1']; ?></td>
                    <td><?php echo $row['q2']; ?></td>
                    <td><?php echo $row['text']; ?></td>
                </tr>
            </tbody>
            <?php endwhile; ?>
        </table>
    </body>
</html>